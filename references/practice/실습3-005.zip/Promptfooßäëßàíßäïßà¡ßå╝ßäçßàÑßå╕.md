Promptfoo가 뭐야

- LLM 애플리케이션에서 프롬프트 + 모델 + 입력(test case) 조합으로 출력 비교/평가를 자동화해주는 도구. 
- 명령줄(CLI) + 라이브러리 형태로 사용 가능하고, 결과를 웹 UI로 시각화해서 비교하기 좋음


## 설치 (npm, npx)
# 예: init할 때
npx promptfoo@latest init

## 프로젝트 초기화 
기본 설정 파일이랑 예제(prompt, test case 등) 생성 가능

promptfoo init --example getting-started

또는 그냥 promptfoo init 해서 빈 구성부터 시작.

구성 (config) 주요 요소

promptfooconfig.yaml 같은 YAML 파일을 통해 여러 요소를 설정함. 주요 항목은 다음:

항목	역할 / 의미
prompts	테스트할 프롬프트 템플릿들. {{변수}} 형태로 변수 자리 둬서 다양한 입력(vars)와 조합 가능. 
providers	어떤 LLM 모델들을 쓸지 설정 (예: OpenAI, Claude, VertexAI, 또는 로컬 모델)
tests (test cases)	어떤 입력(vars)로 프롬프트를 돌릴지. 예: 언어(language), 문장(input) 등. 
assertions (옵션)	출력이 특정 조건을 만족하는지 자동으로 체크하는 로직. 예: “JSON 형태인지”, “포함 단어가 있는지”, “의미적으로 유사한지(similarity)” 등.



실행 흐름
1. promptfoo init → 설정 파일 + prompt + 기본 구조 준비
2. promptfoo eval → 모든 조합(prompt × provider × test case) 실행해서 결과 수집 
3. 결과 보기: promptfoo view → 웹 UI 통해 비교 분석 가능 ✯ 어떤 모델/프롬프트가 잘 안됨 → 왜 그런지 확인 가능함.